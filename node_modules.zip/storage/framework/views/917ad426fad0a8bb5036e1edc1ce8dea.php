<?php $__env->startSection('title', $post->title); ?>
<?php $__env->startSection('description', $post->meta_description); ?>
<?php $__env->startSection('keywords', $post->meta_keywords); ?>
<?php $__env->startSection('image', asset('uploads/' . $post->image)); ?>
<?php $__env->startSection('meta_title', $post->meta_title); ?>

<?php $__env->startSection('head'); ?>
<?php echo $post->custom_header; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_css'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<style>
  #post-img {
    width: 90%;
    align-items: center;
  }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-id'); ?>
<div class="breadcrumbs d-flex align-items-center" style="background-image: url(<?php echo e(asset('images/blog-header.jpg')); ?>);">
  <div class="container position-relative d-flex flex-column align-items-center">

    <h2><?php echo e($post->title); ?></h2>
    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li><?php echo e($post->title); ?></li>
    </ol>

  </div>
</div>

<section id="blog" class="blog">
  <div class="container" data-aos="fade-up">

    <div class="row g-5">

      <div class="col-lg-8" data-aos="fade-up" data-aos-delay="200">

        <article class="blog-details" style="box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);">


          <h2 class="title"><?php echo e($post->title); ?></h2>
          <br><br>
          <div class="post-img" style="text-align: center;">
            <img src="<?php echo e(asset('uploads/' . $post->image)); ?>" alt="" class="img-fluid" id="post-img">
          </div>


          <div class="meta-top">
            <ul>
              <li class="d-flex align-items-center">
                <i class="bi bi-person"></i>
                <a href="javascript:void(0)"><?php echo e($post->user->name); ?></a>
              </li>
              <li class="d-flex align-items-center">
                <i class="bi bi-clock"></i>
                <a href="javascript:void(0)">
                  <time datetime="<?php echo e($post->created_at); ?>"><?php echo e($post->created_at->format('Y-m-d')); ?></time>
                </a>
              </li>
              <li class="d-flex align-items-center">
                <i class="bi bi-chat-dots"></i>
                <a href="javascript:void(0)"><?php echo e($totalComments); ?> Comments</a>
              </li>
            </ul>
          </div>
          <!-- End meta top -->

          <div class="content">
            <?php echo $post->content; ?>

          </div>
          <!-- End post content -->

          <div class="meta-bottom">
            <i class="<?php echo e($post->category->icon); ?>"></i>
            <ul class="cats">
              <li><a href="<?php echo e(route('categories', Str::lower($post->category->name))); ?>"><?php echo e($post->category->name); ?></a></li>
            </ul>

            <i class="bi bi-tags"></i>
            <ul class="tags">
              <?php if(!empty(array_filter($postTags))): ?>
              <?php $__currentLoopData = $postTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postTag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(!empty($postTag)): ?>
              <li>
                <a href="<?php echo e(route('post-by-tag', $postTag)); ?>">
                  <?php echo e(Str::title($postTag)); ?>

                </a>
              </li>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <li>
                <a href="javascript:void(0)">Belum ada tag.</a>
              </li>
              <?php endif; ?>
            </ul>
          </div>
          <!-- End meta bottom -->
        </article>
        <!-- End blog post -->

        <div class="comments">

          <h4 class="comments-count"><?php echo e($totalComments > 0 ? $totalComments : 0); ?> Comments</h4>


          <?php $__currentLoopData = $activeComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <?php
          if ($comment->user->role === 'user') {
          $badgeColor = "primary";
          } else {
          $badgeColor = "success";
          }
          ?>

          <div id="comment-1" class="comment">
            <div class="d-flex">
              <div class="comment-img">
                <img src="https://ui-avatars.com/api/?name=<?php echo e(Str::slug($comment->user->name, '+')); ?>" alt="">
              </div>
              <div>
                <h5>
                  <a href="">
                    <?php echo e($comment->user->name); ?>

                  </a>
                  <?php if($comment->user->role !== 'admin'): ?>
                  <span class="badge rounded-pill text-bg-<?php echo e($badgeColor); ?>"><?php echo e(Str::lower($comment->user->role)); ?></span>
                  <?php endif; ?>
                </h5>
                <time datetime="2020-01-01"><?php echo e($comment->created_at->format('M d, Y')); ?></time>
                <p>
                  <?php echo e($comment->content); ?>

                </p>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- End comment -->

          <?php
          $disabledForm = $post->allowed_comment ? '' : 'disabled';
          ?>

          <div class="reply-form">

            <h4>Leave a Reply</h4>
            <p>Your email address will not be published. Required fields are marked * </p>
            <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Login to comment</a>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('store-comment', $post->slug)); ?>#comment-section" method="POST" id="comment-section">
              <?php echo method_field('POST'); ?>
              <?php echo csrf_field(); ?>
              
        
        <div class="row">
          <div class="col form-group">
            <textarea name="content" class="form-control" placeholder="Your Comment*" rows="6" <?php echo e($disabledForm); ?>></textarea>
            <?php if($errors->has('content')): ?>
            <span class="help-block text-danger">
              <p><?php echo e($errors->first('content')); ?></p>
            </span>
            <?php endif; ?>
          </div>
        </div>
        <button type="submit" class="btn btn-primary" <?php echo e($disabledForm); ?>>Post Comment</button>
        </form>
        <?php endif; ?>
      </div>
    </div>
    <!-- End blog comments -->
  </div>

  <div class="col-lg-4" data-aos="fade-up" data-aos-delay="400">

    <div class="sidebar ps-lg-4">

      <div class="sidebar-item categories">
        <h3 class="sidebar-title">Categories</h3>
        <ul class="mt-3">
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
            <a href="<?php echo e(route('categories', Str::lower($category->name))); ?>">
              <?php echo e($category->name); ?>

              <span>
                (<?php echo e($category->posts_count); ?>)
              </span>
            </a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><!-- End sidebar categories-->

      <div class="sidebar-item recent-posts">
        <h3 class="sidebar-title">Related Posts</h3>

        <div class="mt-3">

          <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($relatedPost->active == 1): ?>
          <div class="post-item">
            <img src="<?php echo e(asset('uploads/' . $relatedPost->image)); ?>" alt="" class="flex-shrink-0">
            <div>
              <h4><a href="<?php echo e(route('post', $relatedPost->slug)); ?>"><?php echo e($relatedPost->title); ?></a></h4>
              <time datetime="2020-01-01"><?php echo e($relatedPost->created_at->format('M d, Y')); ?></time>
            </div>
          </div>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- End recent post item-->
        </div>
      </div>
      <!-- End sidebar recent posts-->

      <div class="sidebar-item tags">
        <h3 class="sidebar-title">Tags</h3>
        <ul class="mt-3">
          <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
            <a href="<?php echo e(route('post-by-tag', $tag)); ?>">
              <?php echo e(Str::title($tag)); ?>

            </a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
    <!-- End Blog Sidebar -->
  </div>
  </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<script>
  $(document).ready(function() {
    $("table").addClass("table table-striped table-bordered");
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.templates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\blogger\resources\views/blog/post.blade.php ENDPATH**/ ?>