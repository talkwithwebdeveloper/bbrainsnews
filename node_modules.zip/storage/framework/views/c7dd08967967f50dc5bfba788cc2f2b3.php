

<?php $__env->startSection('content'); ?>
    <h1>Header Management</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('header.create')); ?>" class="btn btn-primary">Create New Header</a>


    <!-- <link rel="canonical" href="<?php echo e(config('variables.productPage') ? config('variables.productPage') : ''); ?>"> -->


    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Value</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($header->id); ?></td>
                    <td><?php echo e(\Illuminate\Support\Str::limit($header->value, 200, '...')); ?></td>
                    <td>
                        <a href="<?php echo e(route('header.edit', $header)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('header.destroy', $header)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_v2.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mian\resources\views/admin/header/index.blade.php ENDPATH**/ ?>