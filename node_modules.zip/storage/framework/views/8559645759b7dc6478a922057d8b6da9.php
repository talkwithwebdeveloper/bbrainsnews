<?php $__env->startSection('title', __('Not Found')); ?>

<?php $__env->startSection('code', '404'); ?>

<?php $__env->startSection('message'); ?>
<p>
  The page you are looking for might have been removed had its name
  changed or is temporarily unavailable.
</p>
<a href="<?php echo e(route('home')); ?>">Homepage</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mian\blogger\resources\views/errors/404.blade.php ENDPATH**/ ?>