<?php $__env->startSection('page_css'); ?>
	<link href="<?php echo e(asset('admin_v2/css/iconly.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-heading">
	<h3>Profile Statistics</h3>
</div>

<div class="page-content">
	<section class="row justify-content-center">
		<div class="col-6 col-lg-3 col-md-6">
			<div class="card">
				<div class="card-body px-4 py-4-5">
					<div class="row">
						<div
							class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start"
						>
							<div class="stats-icon purple mb-2">
								<i class="iconly-boldPaper"></i>
							</div>
						</div>
						<div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
							<h6 class="text-muted font-semibold">Articles Created</h6>
							<h6 class="font-extrabold mb-0"><?php echo e($totalPosts); ?></h6>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-6 col-lg-3 col-md-6">
			<div class="card">
				<div class="card-body px-4 py-4-5">
					<div class="row">
						<div
							class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start"
						>
							<div class="stats-icon blue mb-2">
								<i class="iconly-boldChat"></i>
							</div>
						</div>
						<div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
							<h6 class="text-muted font-semibold">Comments Given</h6>
							<h6 class="font-extrabold mb-0"><?php echo e($totalComments); ?></h6>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php if(Auth::user()->role == 'admin'): ?>
			<div class="col-6 col-lg-3 col-md-6">
				<div class="card">
					<div class="card-body px-4 py-4-5">
						<div class="row">
							<div
								class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start"
							>
								<div class="stats-icon green mb-2">
									<i class="iconly-boldCategory"></i>
								</div>
							</div>
							<div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
								<h6 class="text-muted font-semibold">
									Categories Created
								</h6>
								<h6 class="font-extrabold mb-0"><?php echo e($totalCategories); ?></h6>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-6 col-lg-3 col-md-6">
				<div class="card">
					<div class="card-body px-4 py-4-5">
						<div class="row">
							<div
								class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start"
							>
								<div class="stats-icon red mb-2">
									<i class="iconly-boldUser"></i>
								</div>
							</div>
							<div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
								<h6 class="text-muted font-semibold">Total Users</h6>
								<h6 class="font-extrabold mb-0"><?php echo e($totalUsers); ?></h6>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
	<script src="<?php echo e(asset('admin_v2/js/dashboard.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_v2.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mian\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>