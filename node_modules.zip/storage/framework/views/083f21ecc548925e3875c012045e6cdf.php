<script type="text/javascript" src="<?php echo e(asset('js/artikel_v2/bootstrap.bundle.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/artikel_v2/main.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/artikel_v2/aos.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\Laravel\blogger\resources\views/includes/scripts.blade.php ENDPATH**/ ?>