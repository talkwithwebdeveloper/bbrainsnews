<script src="<?php echo e(asset('admin_v2/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_v2/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_v2/js/dataTables.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_v2/js/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('admin_v2/js/custom.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\Laravel\blogger\resources\views/includes/admin_v2/plugin-script.blade.php ENDPATH**/ ?>