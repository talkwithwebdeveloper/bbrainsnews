<?php if(Session::has('success')): ?>
<div
	class="alert alert-light-success color-success alert-dismissible fade show"
	role="alert"
>
	<button
		type="button"
		class="btn-close"
		data-bs-dismiss="alert"
		aria-label="Close"
	></button>

	<i class="bi bi-check-circle"></i>
	<?php echo e(Session::get('success')); ?>

</div>
<?php elseif(Session::has('danger')): ?>
<div
	class="alert alert-light-danger color-danger alert-dismissible fade show"
	role="alert"
>
	<button
		type="button"
		class="btn-close"
		data-bs-dismiss="alert"
		aria-label="Close"
	></button>

	<i class="bi bi-exclamation-circle"></i>
	<?php echo e(Session::get('danger')); ?>

</div>
<?php elseif(Session::has('warning')): ?>
<div
	class="alert alert-light-warning color-warning alert-dismissible fade show"
	role="alert"
>
	<button
		type="button"
		class="btn-close"
		data-bs-dismiss="alert"
		aria-label="Close"
	></button>

	<i class="bi bi-exclamation-triangle"></i>
	<?php echo e(Session::get('warning')); ?>

</div>
<?php elseif(Session::has('info')): ?>
<div
	class="alert alert-light-info color-info alert-dismissible fade show"
	role="alert"
>
	<button
		type="button"
		class="btn-close"
		data-bs-dismiss="alert"
		aria-label="Close"
	></button>

	<i class="bi bi-info-circle"></i>
	<?php echo e(Session::get('info')); ?>

</div>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\Laravel\blogger\resources\views/includes/admin_v2/alerts.blade.php ENDPATH**/ ?>