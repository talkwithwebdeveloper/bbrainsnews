<header id="header" class="header d-flex align-items-center fixed-top">
  <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

    <a href="<?php echo e(route('home')); ?>" class="logo d-flex align-items-center">

      <h2 class="d-flex align-items-center" style="color: white;">Tint Law</h2>
    </a>

    <i class="mobile-nav-toggle mobile-nav-show fa-solid fa-bars"></i>
    <i class="mobile-nav-toggle mobile-nav-hide d-none fa-solid fa-xmark"></i>

    <nav id="navbar" class="navbar">
      <ul>
        <li>
          <a href="<?php echo e(route('home')); ?>" <?php if(Request::segment('1') == ''): ?> class="active" <?php endif; ?>>
            Home
          </a>
        </li>
        <?php if(auth()->guard()->guest()): ?>
          <li>
            <a href="<?php echo e(route('login')); ?>">
              Login
            </a>
          </li>
        <?php endif; ?>
          
        <?php if(auth()->guard()->check()): ?>
          <?php if(Auth::user()->role !== 'user'): ?>
            <li class="dropdown">
              <a href="#">
                <span><?php echo e(Auth::user()->name); ?></span>
                <i class="bi bi-chevron-down dropdown-indicator"></i>
              </a>
              <ul>
                <li>
                  <a href="<?php echo e(route('dashboard')); ?>">
                    Dashboard
                  </a>
                </li>
                <li>
                  <a
                    href="<?php echo e(route('logout')); ?>"
                    onclick="
                      event.preventDefault();
                      document.getElementById('logout-form').submit();"
                  >
                    Logout
                  </a>
                </li>
              </ul>
            </li>
          <?php else: ?>
            <li>
              <a
                href="<?php echo e(route('logout')); ?>"
                onclick="
                  event.preventDefault();
                  document.getElementById('logout-form').submit();"
              >
                Logout
              </a>
            </li>
          <?php endif; ?>
        <?php endif; ?>
      </ul>

      <form
        id="logout-form"
        action="<?php echo e(route('logout')); ?>"
        method="POST"
        style="display: none"
      >
        <?php echo csrf_field(); ?>
      </form>
    </nav><!-- .navbar -->

  </div>
</header>

<?php /**PATH C:\xampp\htdocs\mian\blogger\resources\views/includes/header.blade.php ENDPATH**/ ?>