<!DOCTYPE html>
<html lang="en">
	<head>
		<?php echo $__env->make('includes.admin_v2.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->yieldContent('page_css'); ?>
	</head>

	<body>
		<script src="<?php echo e(asset('admin_v2/js/initTheme.js')); ?>"></script>
		<div id="app">
			<?php echo $__env->make('includes.admin_v2.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div id="main">
				<header class="mb-3">
					<a href="#" class="burger-btn d-block d-xl-none">
						<i class="bi bi-justify fs-3"></i>
					</a>
				</header>
				
				<?php echo $__env->yieldContent('content'); ?>
			</div>
		</div>
		
		<?php echo $__env->make('includes.admin_v2.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->yieldContent('page_scripts'); ?>
	</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\blogger\resources\views/layouts/admin_v2/template.blade.php ENDPATH**/ ?>