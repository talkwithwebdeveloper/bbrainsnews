<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
	<head>
		<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->yieldContent('page_css'); ?>
	</head>
	<body class="page-blog">
		<!--start-header-->
		<?php if(!isset($hideNavbar) || !$hideNavbar): ?>
			<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endif; ?>
		<!--End-header-->
		<main id="main">
			<!--Main-Content-->
			<?php echo $__env->yieldContent('content-id'); ?>
			<!--Main-Content-end-->
		</main>
		<!--footer-starts-->
		
		<!--global-Js-->
		<?php echo $__env->make('includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
		<?php echo $__env->yieldContent('page_scripts'); ?>
	</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\blogger\resources\views/layouts/templates.blade.php ENDPATH**/ ?>