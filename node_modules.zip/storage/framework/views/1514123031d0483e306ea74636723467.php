<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title><?php echo $__env->yieldContent('title'); ?></title>

		<!-- Google font -->
		<link
			href="https://fonts.googleapis.com/css?family=Oswald:700"
			rel="stylesheet"
		/>
		<link
			href="https://fonts.googleapis.com/css?family=Lato:400"
			rel="stylesheet"
		/>

		<!-- Custom stlylesheet -->
		<link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/404/style.css')); ?>" />

	</head>
	<body>
		<div id="notfound">
			<div class="notfound-bg">
				<div></div>
				<div></div>
				<div></div>
				<div></div>
			</div>
			<div class="notfound">
				<div class="notfound-404">
					<h1><?php echo $__env->yieldContent('code'); ?></h1>
				</div>
				<h2><?php echo $__env->yieldContent('title'); ?></h2>
				
				<?php echo $__env->yieldContent('message'); ?>
			</div>
		</div>
	</body>
</html>
<?php /**PATH C:\xampp\htdocs\mian\resources\views/errors/layout.blade.php ENDPATH**/ ?>