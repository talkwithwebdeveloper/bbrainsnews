<script src="<?php echo e(asset('admin_v2/js/dark.js')); ?>"></script>
<script src="<?php echo e(asset('admin_v2/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('admin_v2/js/perfect-scrollbar.min.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\mian\blogger\resources\views/includes/admin_v2/scripts.blade.php ENDPATH**/ ?>