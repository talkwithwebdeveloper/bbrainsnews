<?php $__env->startSection('page-title', 'Home'); ?>

<?php $__env->startSection('content-id'); ?>
<!-- ======= Breadcrumbs ======= -->
<div class="breadcrumbs d-flex align-items-center" style="background-image: url(<?php echo e(asset('images/blog-header.jpg')); ?>);">
  <div class="container position-relative d-flex flex-column align-items-center">

    <h2>Blog</h2>
    <ol>
      <li><a href="/">Home</a></li>
      <li>Blog</li>
    </ol>

  </div>
</div>

<section id="blog" class="blog">
  <div class="container" data-aos="fade-up">

    <div class="row g-5">

      <div class="col-lg-8" data-aos="fade-up" data-aos-delay="200">

        <div class="row gy-5 posts-list">

          <?php if(count($posts) > 0): ?>
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-6">
            <article class="d-flex flex-column">

              <div class="post-img">
                <img src="<?php echo e(asset('uploads/' . $post->image)); ?>" alt="" class="img-fluid">
              </div>

              <h2 class="title">
                <a href="<?php echo e(route('post', $post->slug)); ?>"><?php echo e($post->title); ?></a>
              </h2>

              <div class="meta-top">
                <ul>
                  <li class="d-flex align-items-center">
                    <i class="bi bi-person"></i>
                    <a href="<?php echo e(route('post-by-user', $post->user->slug)); ?>">
                      <?php echo e($post->user->name); ?>

                    </a>
                  </li>
                  <li class="d-flex align-items-center">
                    <i class="bi bi-clock"></i>
                    <a href="<?php echo e(route('post', $post->slug)); ?>">
                      <time datetime="<?php echo e($post->created_at); ?>">
                        <?php echo e($post->created_at->format('m/d/Y')); ?>


                      </time>
                    </a>
                  </li>
                  <li class="d-flex align-items-center">
                    <i class="bi bi-chat-dots"></i>
                    <a href="<?php echo e(route('post', $post->slug)); ?>">
                      <?php echo e($post->activeCommentsCount > 0 ? $post->activeCommentsCount : 0); ?> Comments
                    </a>
                  </li>
                </ul>
              </div>

              <?php
              $pTag = getParagraphTagOnly($post->content);
              ?>

              <div class="content">
                <p>
                <?php echo e(\Illuminate\Support\Str::limit($post->meta_description, 150, '...')); ?>

                </p>
              </div>

              <div class="read-more mt-auto align-self-end">
                <a href="<?php echo e(route('post', $post->slug)); ?>">Read More <i class="fa-solid fa-arrow-right"></i></a>
              </div>

            </article>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <p class="text-center">No artikel found.</p>
          <?php endif; ?>

        </div><!-- End blog posts list -->

        <div class="blog-pagination">
          <ul class="justify-content-center">
            <?php for($i = 1; $i <= $posts->lastPage(); $i++): ?>
              <li class="<?php echo e($i === $posts->currentPage() ? 'active' : ''); ?>">
                <a href="<?php echo e($posts->url($i)); ?>"><?php echo e($i); ?></a>
              </li>
              <?php endfor; ?>
          </ul>
        </div>
        <!-- End blog pagination -->
      </div>

      <?php echo $__env->make('partials._sidebar', [
      'categories' => $categories,
      'tags' => $tags
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.templates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mian\blogger\resources\views/home.blade.php ENDPATH**/ ?>