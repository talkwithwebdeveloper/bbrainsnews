<div class="col-lg-4" data-aos="fade-up" data-aos-delay="400">

  <div class="sidebar ps-lg-4">
    <div class="sidebar-item search-form">
      <h3 class="sidebar-title">Search</h3>
      <form action="<?php echo e(route('search')); ?>" class="mt-3" method="GET" id="search-form">
        <input type="text" name="q" placeholder="Find article ...">
        <button type="submit" onclick="submitSearchForm()">
          <i class="bi bi-search"></i>
        </button>
      </form>
    </div>
    <!-- End sidebar search formn-->

    <div class="sidebar-item categories">
      <h3 class="sidebar-title">Categories</h3>
      <ul class="mt-3">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
            <a href="<?php echo e(route('categories', Str::lower($category->name))); ?>"><?php echo e($category->name); ?>

              <span>
                (<?php echo e($category->posts_count); ?>)
              </span>
            </a>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <!-- End sidebar categories-->

    <div class="sidebar-item tags">
      <h3 class="sidebar-title">Tags</h3>
      <ul class="mt-3">
        <?php if(!$tags->isEmpty()): ?>
          <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($tag)): ?>
              <li>
                <a href="<?php echo e(route('post-by-tag', $tag)); ?>">
                  <?php echo e(Str::title($tag)); ?>

                </a>
              </li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <p class="fs-6">No tags found.</p>
        <?php endif; ?>
      </ul>
    </div>

  </div>
  <!-- End Blog Sidebar -->

</div>

<?php $__env->startSection('page_scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/mark.js/8.11.1/mark.min.js" integrity="sha512-5CYOlHXGh6QpOFA/TeTylKLWfB3ftPsde7AnmhuitiTX4K5SqCLBeKro6sPS8ilsz1Q4NRx3v8Ko2IBiszzdww==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  
  <script>
    /**
     * Highlight searched text result
     */
    function highlightText() {
      const searchQuery = new URLSearchParams(window.location.search).get("q");

      if (searchQuery) {
        const postsList = new Mark(document.querySelector(".posts-list"));
        postsList.unmark();
        postsList.mark(searchQuery);
      }
    }

    document.addEventListener("DOMContentLoaded", highlightText);

    function submitSearchForm() {
      document.getElementById("search-form").submit();
    }
  </script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\mian\resources\views/partials/_sidebar.blade.php ENDPATH**/ ?>