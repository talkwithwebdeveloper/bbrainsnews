<script>
  document.addEventListener('DOMContentLoaded', function () {
    <?php if(Session::has('tsuccess')): ?>
      Toastify({
        text: "<?php echo e(Session::get('tsuccess')); ?>",
        duration: 3000,
        close: true,
        gravity: "top",
        position: 'center',
        backgroundColor: "#22c55e",
      }).showToast();
    <?php endif; ?>

    <?php if(Session::has('tdanger')): ?>
      Toastify({
        text: "<?php echo e(Session::get('tdanger')); ?>",
        duration: 3000,
        close: true,
        gravity: "top",
        position: 'center',
        backgroundColor: "#e11d48",
      }).showToast();
    <?php endif; ?>
  });
</script>
<?php /**PATH C:\xampp\htdocs\mian\blogger\resources\views/includes/toast.blade.php ENDPATH**/ ?>