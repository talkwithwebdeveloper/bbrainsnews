<?php $__env->startSection('title', __('Page Expired')); ?>

<?php $__env->startSection('code', '419'); ?>

<?php $__env->startSection('message'); ?>
<p>
  Please log in again. Your authentication session has expired. Make sure you enter your login details correctly.
</p>
<a href="<?php echo e(route('login')); ?>">Return to login page</a>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('errors::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mian\resources\views/errors/419.blade.php ENDPATH**/ ?>