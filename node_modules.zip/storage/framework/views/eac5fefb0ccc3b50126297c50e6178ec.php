

<?php $__env->startSection('content'); ?>
    <h1>Create Header</h1>

    <form action="<?php echo e(route('header.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="value">Header Value</label>
            <textarea name="value" class="form-control" id="value" required style="height: 500px;"><?php echo e(old('value')); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_v2.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mian\resources\views/admin/header/create.blade.php ENDPATH**/ ?>