<?php $__env->startSection('page_css'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('admin_v2/css/use-bootstrap-tag.min.css')); ?>">

	<style>
		.ck-editor__editable_inline:not(.ck-comment__input *) {
			height: 300px;
			overflow-y: auto;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-heading">
	<div class="page-title">
		<div class="row">
			<div class="col-12 col-md-6 order-md-1 order-last">
				<h3>Features</h3>
			</div>
			<div class="col-12 col-md-6 order-md-2 order-first">
				<nav
					aria-label="breadcrumb"
					class="breadcrumb-header float-start float-lg-end"
				>
					<ol class="breadcrumb">
						<li class="breadcrumb-item">
							<a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
						</li>
						<li class="breadcrumb-item active" aria-current="page">
							Edit Article
						</li>
					</ol>
				</nav>
			</div>
		</div>
	</div>

	<section id="basic-vertical-layouts">
		<div class="row match-height">
			<div class="col-12">
				<div class="card">
					<div class="card-header">
						<h4 class="card-title">Edit Article</h4>
					</div>
					<div class="card-content">
						<div class="card-body">
							<form class="form form-vertical" action="<?php echo e(route('article.update', $post->id)); ?>" enctype="multipart/form-data" method="POST" id="editPost">
								<?php echo method_field('PATCH'); ?>
								<?php echo csrf_field(); ?>
								<div class="form-body">
									<div class="row">
										<div class="col-12">
											<div class="form-group">
												<label for="first-name-vertical">Title*</label>
												<input
													type="text"
													class="form-control"
													name="title"
													value="<?php echo e($post->title); ?>"
												/>
												<?php if($errors->has('title')): ?>
													<span class="help-block text-danger">
														<p><?php echo e($errors->first('title')); ?></p>
													</span>
												<?php endif; ?>
											</div>
										</div>
										<div class="col-12">
											<div class="form-group">
												<label for="email-id-vertical">Content*</label>
												<textarea id="content" name="content">
													<?php echo $post->content; ?>

												</textarea>
												<?php if($errors->has('content')): ?>
													<span class="help-block text-danger">
														<p><?php echo e($errors->first('content')); ?></p>
													</span>
												<?php endif; ?>
											</div>
										</div>
										<div class="col-12">
											<div class="form-group">
												<label for="contact-info-vertical">Category*</label>
												<select class="form-control" style="width: 100%;" name="category_id">
													<option value="<?php echo e($post->id); ?>"><?php echo e($post->category->name); ?></option>
													<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
											</div>
										</div>
										<div class="col-12">
											<div class="form-group">
												<label for="password-vertical">Image*</label>
												<input
													class="form-control"
													type="file"
													id="image"
													name="image"
												/>
											</div>

											<img id="preview_image" class="inputImgPreview w-25 mt-2" src="<?php echo e(asset('uploads/' . $post->image ?? '')); ?>" />

											<?php if($errors->has('image')): ?>
												<span class="help-block text-danger">
													<p><?php echo e($errors->first('image')); ?></p>
												</span>
											<?php endif; ?>
										</div>
										<div class="col-12">
											<div class="form-group">
												<label for="first-name-vertical">Tags*</label>
												<input
													type="text"
													class="form-control"
													name="tags"
													id="tags"
													data-ub-tag-variant="dark"
													value="<?php echo e($post->tags); ?>"
												/>

												<?php if($errors->has('tags')): ?>
													<span class="help-block text-danger">
														<p><?php echo e($errors->first('tags')); ?></p>
													</span>
												<?php endif; ?>
											</div>
										</div>
										<div class="col-12">
											<div class="form-group">
												<label for="first-name-vertical">Meta Title*</label>
												<input
													type="text"
													class="form-control"
													name="meta_title"
													id="meta_title"
													data-ub-tag-variant="dark"
													value="<?php echo e($post->meta_title); ?>"
												/>

												<?php if($errors->has('meta_title')): ?>
													<span class="help-block text-danger">
														<p><?php echo e($errors->first('meta_title')); ?></p>
													</span>
												<?php endif; ?>
											</div>
										</div>
										<div class="col-12">
											<div class="form-group">
												<label for="first-name-vertical">Meta description*</label>
												<textarea
													type="text"
													class="form-control"
													name="meta_description"
													id="meta_description"
													data-ub-tag-variant="dark"
													value="<?php echo e($post->meta_description); ?>"
												><?php echo e($post->meta_description); ?></textarea>

												<?php if($errors->has('meta_description')): ?>
													<span class="help-block text-danger">
														<p><?php echo e($errors->first('meta_description')); ?></p>
													</span>
												<?php endif; ?>
											</div>
										</div>
										<div class="col-12">
											<div class="form-group">
												<label for="first-name-vertical">Custom Header*</label>
												<input
													type="text"
													class="form-control"
													name="custom_header"
													id="custom_header"
													data-ub-tag-variant="dark"
													value="<?php echo e($post->custom_header); ?>"
												/>

												<?php if($errors->has('custom_header')): ?>
													<span class="help-block text-danger">
														<p><?php echo e($errors->first('custom_header')); ?></p>
													</span>
												<?php endif; ?>
											</div>
										</div>
										<div class="col-12">
											<div class="form-group">
												<label for="first-name-vertical">Meta Keywords*</label>
												<input
													type="text"
													class="form-control"
													name="meta_keywords"
													id="meta_keywords"
													data-ub-tag-variant="dark"
													value="<?php echo e($post->meta_keywords); ?>"
												/>

												<?php if($errors->has('meta_keywords')): ?>
													<span class="help-block text-danger">
														<p><?php echo e($errors->first('meta_keywords')); ?></p>
													</span>
												<?php endif; ?>
											</div>
										</div>

										<div class="col-12">
											<div class="form-group">
												<label class="mb-1">Allow comment?</label>
												<div class="form-check">
													<input
														class="form-check-input form-check-success"
														type="radio"
														name="allowed_comment"
														id="yesComment"
														value="1"
														<?php echo e($post->allowed_comment == 1 ? 'checked' : ''); ?>

													/>
													<label
														class="form-check-label"
														for="yesComment"
													>
														Yes
													</label>
												</div>
												<div class="form-check">
													<input
														class="form-check-input form-check-danger"
														type="radio"
														name="allowed_comment"
														id="noComment"
														value="0"
														<?php echo e($post->allowed_comment == 0 ? 'checked' : ''); ?>

													/>
													<label
														class="form-check-label"
														for="noComment"
													>
														No
													</label>
												</div>
											</div>
										</div>
										<div class="col-12">
											<div class="form-group">
												<label class="mb-1">Publish article?</label>
												<div class="form-check">
													<input
														class="form-check-input form-check-success"
														type="radio"
														name="active"
														id="publishRadio"
														value="1"
														<?php echo e($post->active == 1 ? 'checked' : ''); ?>

													/>
													<label
														class="form-check-label"
														for="publishRadio"
													>
														Yes
													</label>
												</div>
												<div class="form-check">
													<input
														class="form-check-input form-check-danger"
														type="radio"
														name="active"
														id="unpublishedRadio"
														value="0"
														<?php echo e($post->active == 0 ? 'checked' : ''); ?>

													/>
													<label
														class="form-check-label"
														for="unpublishedRadio"
													>
														No
													</label>
												</div>
											</div>
										</div>
										<div class="col-12 d-flex justify-content-end">
											<button
												type="submit"
												class="btn btn-primary btn-block me-1 my-2"
											>
												Update
											</button>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
	<script type="text/javascript" src="<?php echo e(asset('admin_v2/js/ckeditor.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('admin_v2/js/use-bootstrap-tag.min.js')); ?>"></script>

	<script type="text/javascript" src="<?php echo e(asset('admin_v2/js/jquery.min.js')); ?>"></script>

	<script>
		ClassicEditor
			.create(document.querySelector('#content'))
			.catch(error => {
				console.error(error);
			});
	</script>

	<script type="text/javascript">
		UseBootstrapTag(document.getElementById('tags'))

		document.getElementById('image').addEventListener('change', function(e) {
			var fileName = e.target.files[0].name;
			document.getElementById('file-label').textContent = fileName;
		});

		function readURL(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				var targetPreview = 'preview_'+$(input).attr('id');
				reader.onload = function(e) {
						$('#'+targetPreview).attr('src', e.target.result).show();
				}
				reader.readAsDataURL(input.files[0]);
			}
		}
		$("#image").change(function() {
			readURL(this);
		});
	</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_v2.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\blogger\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>