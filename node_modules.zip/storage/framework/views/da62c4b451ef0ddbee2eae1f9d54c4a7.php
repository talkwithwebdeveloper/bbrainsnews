<?php $__env->startSection('content'); ?>
<div class="page-heading">
	<div class="page-title">
		<div class="row">
			<div class="col-12 col-md-6 order-md-1 order-last">
				<h3>Features</h3>
			</div>
			<div class="col-12 col-md-6 order-md-2 order-first">
				<nav
					aria-label="breadcrumb"
					class="breadcrumb-header float-start float-lg-end"
				>
					<ol class="breadcrumb">
						<li class="breadcrumb-item">
							<a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
						</li>
						<li class="breadcrumb-item active" aria-current="page">
							Create Category
						</li>
					</ol>
				</nav>
			</div>
		</div>
	</div>

	<section id="basic-vertical-layouts">
		<div class="row match-height">
			<div class="col-12">
				<div class="card">
					<div class="card-header">
						<h4 class="card-title">Create Category</h4>
					</div>
					<div class="card-content">
						<div class="card-body">
							<form class="form form-vertical" action="<?php echo e(route('category.store')); ?>" method="POST">
								<?php echo csrf_field(); ?>
								<div class="form-body">
									<div class="row">
										<div class="col-12">
											<div class="form-group">
												<label for="first-name-vertical">Name*</label>
												<input
													type="text"
													class="form-control"
													name="name"
													placeholder="Category name"
													value="<?php echo e(old('name')); ?>"
												/>
												<?php if($errors->has('name')): ?>
													<span class="help-block text-danger">
														<p><?php echo e($errors->first('name')); ?></p>
													</span>
												<?php endif; ?>
											</div>
										</div>
										<div class="col-12">
											<div class="form-group">
												<label for="first-name-vertical">Icon*</label>
												<input
													type="text"
													class="form-control"
													name="icon"
													placeholder="Ex: bi bi-people-fill (bootstrap icons)"
													value="<?php echo e(old('icon')); ?>"
												/>
												<?php if($errors->has('icon')): ?>
													<span class="help-block text-danger">
														<p><?php echo e($errors->first('icon')); ?></p>
													</span>
												<?php endif; ?>
											</div>
										</div>
										<div class="col-12 d-flex justify-content-end">
											<button
												type="submit"
												class="btn btn-primary btn-block me-1 my-2"
											>
												Submit
											</button>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_v2.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mian\blogger\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>