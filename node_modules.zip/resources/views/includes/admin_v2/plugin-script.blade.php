<script src="{{ asset('admin_v2/js/jquery.min.js') }}"></script>
<script src="{{ asset('admin_v2/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('admin_v2/js/dataTables.bootstrap5.min.js') }}"></script>
<script src="{{ asset('admin_v2/js/datatables.js') }}"></script>
<script src="{{ asset('admin_v2/js/custom.js') }}"></script>