<script src="{{ asset('admin_v2/js/dark.js') }}"></script>
<script src="{{ asset('admin_v2/js/app.js') }}"></script>
<script src="{{ asset('admin_v2/js/perfect-scrollbar.min.js') }}"></script>