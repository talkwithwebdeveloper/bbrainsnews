<script type="text/javascript" src="{{ asset('js/artikel_v2/bootstrap.bundle.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/artikel_v2/main.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/artikel_v2/aos.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/jquery.min.js') }}"></script>